from flask import Flask, render_template, redirect
from flask_mysqldb import MySQL


app = Flask(__name__)

#config mysql
app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']='roots'
app.config['MYSQL_DB']='seekxdb'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'


#init mysql
mysql = MySQL(app)

#sidebar display
class sidebar():
    #leftsidebar

    def leftsidebar():
        #create cursor
        cur = mysql.connection.cursor()
        #fetch all the data from recent events
        cur.execute("select * from events")
        left_val = cur.fetchall()
        return left_val



    def rightsidebar():
        #create cursor
        cur = mysql.connection.cursor()
        #fetch all the data from recent events
        cur.execute("select * from users_detail where user_id=1")
        right_val = cur.fetchall()
        return right_val




#index
@app.route('/')
def index():
    #crete cursor
    cur = mysql.connection.cursor()
    #fetch all data from post
    result = cur.execute("select u.username, p.post_data, p.create_date, p.image_path from usersdb u inner join postdb p on u.user_id = p.user_id")
    posts = cur.fetchall()
    #left side renering
    left_val = sidebar.leftsidebar()
    #left_val = 1
    #right side rendering
    right_val = sidebar.rightsidebar()
    #right_val = 2


    return render_template('index.html', posts=posts, left_val=left_val, right_val=right_val)
    cur.close()

#members page
@app.route('/members')
def members():
    #create cursor
    cur = mysql.connection.cursor()
    #fetch users detail
    result = cur.execute("select * from usersdetaildb")
    users = cur.fetchall()

    return render_template('members.html', users=users)
    cur.close()

@app.route('/member/<string:id>/')
def member(id):
    #create cursor
    cur = mysql.connection.cursor()
    #fetch member data
    result = cur.execute("SELECT * from usersdetaildb where user_id=%s",[id])
    user = cur.fetchone()
    return render_template('member.html',user=user)

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')





if __name__ == '__main__':
    app.run(debug=True)
    # sidebar.leftsidebar()
    # sidebar.rightsidebar()
